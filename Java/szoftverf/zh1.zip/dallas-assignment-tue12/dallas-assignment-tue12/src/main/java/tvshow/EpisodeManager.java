package tvshow;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface EpisodeManager {

    @SuppressWarnings("unchecked")
    static List<Episode> getEpisodes() {
        try {
            var episodes = (List<Episode>) new ObjectInputStream(EpisodeManager.class.getResourceAsStream("dallas.ser"))
                    .readObject();
            return episodes;
        } catch (IOException | ClassNotFoundException e) {
            throw new AssertionError("Failed to load objects");
        }
    }

    /**
     * Visszaadja egy növekvő sorrendbe rendezett listában az összes olyan
     * különböző évad sorszámát, melyekben van 60 percnél hosszabb epizód.

     * @return egy növekvő sorrendbe rendezett listában az összes olyan
     *         különböző évad sorszáma, melyekben van 60 percnél hosszabb epizód
     */
    List<Integer> getSeasonsWithLongEpisodes();

    /**
     * Visszaadja az évadok első epizódjaihoz tartozó tartalom összefoglalók
     * közül a legrövidebbet.
     *
     * @return az évadok első epizódjaihoz tartozó tartalom összefoglalók
     *         közül a legrövidebb
     */
    Optional<String> getShortestSummaryOfFirstEpisodes();
    
    /**
     * Visszaadja a közönséges epizódok darabszámát aszerint csoportosítva, hogy
     * a hét melyik napján adták őket. Egy epizód közönséges, ha a típusa
     * {@link Type#REGULAR}. Egy {@link LocalDate} objektumhoz a
     * {@link LocalDate#getDayOfWeek()} példányszintű metódus adja vissza, hogy a hét melyik
     * napjára esik a dátum.
     *
     * @return a közönséges epizódok száma aszerint csoportosítva, hogy a hét
     *         melyik napján adták őket
     */
    Map<DayOfWeek, Long> getNumberOfRegularEpisodesByDayOfAirDate();

    /**
     * Visszaadja az összes olyan különböző stábtag számát, akik szerepköre
     * {@code "Writer"}.
     *
     * @return az összes olyan különböző stábtag száma, akik szerepköre
     *         {@code "Writer"}
     */
    long getNumberOfDifferentWriters();

    /**
     * Visszaadja azon epizódok hosszának összegét, melyek címében szerepel a
     * {@code "Ewing"} sztring.
     *
     * @return azon epizódok hosszának összege, melyek címében szerepel a
     *         {@code "Ewing"} sztring
     */
    int getTotalRuntimeOfEpisodesWhoseTitleContainsEwing();

}
