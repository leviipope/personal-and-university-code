package tvshow;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public record Episode(String title,
                      int season,
                      int number,
                      Type type,
                      LocalDate airDate,
                      LocalTime airTime,
                      int runtime,
                      String summary,
                      Double avgRating,
                      List<CrewMember> guestCrew) implements Serializable {
}
