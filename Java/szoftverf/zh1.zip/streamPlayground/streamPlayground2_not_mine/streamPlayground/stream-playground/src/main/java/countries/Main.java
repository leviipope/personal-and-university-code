package countries;


import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Country> coutries=new CountryRepository().getAll();//beolvassa majd visszaadja a jason filet


        //feladat1(coutries);
        //feladat2(coutries);
        //feladat3(coutries);
        //System.out.println(feladat4(coutries));
        //System.out.println(feladat5(coutries));
        //System.out.println(feladat6(coutries));
       // feladat7(coutries);
        // System.out.println(feladat8(coutries));
        //System.out.println(feladat9(coutries));
        //feladat10(coutries);
        //feladat11(coutries);
        //System.out.println(feladat12(coutries));
        //feladat17(coutries);
        //System.out.println(feladat18(coutries));
        //System.out.println(feladat19(coutries));
        //System.out.println(feladat20(coutries));


        //System.out.println(feladat31(coutries));
        //feladat32(countries;
        //System.out.println(feladat33(coutries));
        //System.out.println(feladat34(coutries));
        //System.out.println(feladat35(coutries));
        //System.out.println(feladat36(coutries));
        //System.out.println(feladat37(coutries));
        //feladat38(coutries);
        //System.out.println(feladat39(coutries));
        //System.out.println(feladat310(coutries));
        System.out.println(feladat311(coutries));
    }

    //Mostani feladtaok

    public static Country feladat31(List<Country>countries){
        return countries.stream()
                .filter(country -> country.area()!=null)
                .max(Comparator.comparing(Country::area))//bigdecimal ezert comparing
                .get();
    }


    public static void feladat32(List<Country>countries) {
        countries.stream()
                .filter(country -> country.area() == null)
                .map(country -> country.name())
                .forEach(System.out::println);
    }

    public static DoubleSummaryStatistics feladat33(List<Country>countries) {
        return countries.stream()
                .map(country -> country.area())
                .filter(Objects::nonNull)
                .mapToDouble(BigDecimal::doubleValue)
                .summaryStatistics();
    }


    public static BigDecimal feladat34(List<Country>countries) {
        return countries.stream()
                .map(country -> country.area())
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO,BigDecimal::add); //kezdoertek es akkumulator fg
    }

    public static String feladat35(List<Country>countries) {
        return countries.stream().
                map(country -> country.name())
                .sorted().
                collect(Collectors.joining(","));//a , az elvalaszto karakter
    }


    //ez nincs a dian----asszociativ tomb=map
    public static Map<String,String> feladat36(List<Country>countries) {
        return countries.stream().
                collect(Collectors.toMap(Country::code,Country::name));//kapott ubjektumokbol hogyan valasszak kulcsot es erteket
    }

    //asszociativ tomb=map
   public static Map<String,Country> feladat37(List<Country>countries) {
        return countries.stream().
                collect(Collectors.toMap(Country::code, Function.identity()));
    }

    public static void feladat38(List<Country>countries){
        Country hungary=feladat37(countries).get("HU");
        countries.stream().filter(country -> country.population()<=hungary.population())
                .sorted(Comparator.comparing(Country::population).reversed())
                .forEach(country -> System.out.printf("%s: %d\n",country.name(),country.population()));

    }

    public static Map<Boolean,Long> feladat39(List<Country>countries){
        return countries.stream().
                collect(Collectors.partitioningBy(country -> country.region()==Region.EUROPE,Collectors.counting()));
    }


    public static Map<Region,List<Country>>feladat310(List<Country>countries){
        return countries.stream().collect(Collectors.groupingBy(Country::region));
    }


    public static Map<Region,Long>feladat311(List<Country>countries){
        return countries.stream().collect(Collectors.groupingBy(Country::region,Collectors.counting()));
    }



    public static Map<Region,Double>feladat313(List<Country>countries){
        return countries.stream().
                collect(Collectors.groupingBy(Country::region,Collectors.averagingLong(Country::population)));//a nepesseg long
    }

    //Elozo orai feladatok

    public static void feladat1(List<Country> countries){//hogy ne kelljen peldanyositani  a main t
        countries.stream()
                .map(country -> country.name())//map=lekepezes  .map(Country::name).forEach.....ugyanaz
                .forEach(System.out::println);
    }


    public static void feladat2(List<Country> countries) {
        countries.stream()
                .map(Country::capital)
                .sorted(Comparator.nullsFirst(Comparator.naturalOrder()))//ide kell comparator mert maskepp hiba lesz a null miatt, ketto kell mert az elso a nullt kezeli a masodik a tobbit
                .forEach(System.out::println);
    }

    public static void feladat3(List<Country> countries) {
        countries.stream()
                .map(Country::capital)
                .sorted(Comparator.nullsFirst(Comparator.reverseOrder()))
                .forEach(System.out::println);
    }

    public static Long feladat4(List<Country> countries){
        return countries.stream()
                .mapToLong(country->country.population())
                .max()
                .getAsLong();//long formaban add vissza
        //sima map is jo lenne
    }

    public static Double feladat5(List<Country> countries){
        return countries.stream()
                .mapToLong(country->country.population())
                .average()
                .getAsDouble();//mapTolong kell ide mert olyanertekeknek tud atlagot szamolni

    }

    public static LongSummaryStatistics feladat6(List<Country> countries){
        return countries.
                stream()
                .mapToLong(Country::population)
                .summaryStatistics();//keszit egy osszegzo statisztikat
    }

    public static void feladat7(List<Country> countries)//mert konzolra irunk ezert void
    {
        countries.stream()
                .filter(country->country.region()==Region.EUROPE)
                .map(Country::name)
                .forEach(System.out::println);
    }

    public static Long feladat8(List<Country> countries)
    {
        return countries.stream()
                .filter(country->country.region()==Region.EUROPE)
                .count();
    }

    public static Long feladat9(List<Country> countries)
    {
        return countries.stream()
                .filter(country->country.independent())
                .count();
    }

    public static void feladat10(List<Country>countries){
        countries.stream()
                .filter(country -> country.population()<100)
                .forEach(System.out::println);
    }
    public static void feladat11(List<Country>countries){
        countries.stream()
                .filter(country -> country.population()<100)
                .map(Country::name)
                .forEach(System.out::println);
    }

    public static long feladat12(List<Country> countries){
        return countries.stream()
                .filter(country -> country.region()==Region.EUROPE)
                .mapToLong(Country::population)
                .sum();
    }

    public static void feladat17(List<Country> countries){
        countries.stream()
                .map(country -> country.name())
                .limit(5)
                .forEach(System.out::println);
    }

    public static boolean feladat18(List<Country> countries){
        return countries.stream()
                .anyMatch(country -> country.population()==0);
    }

    public static boolean feladat19(List<Country> countries){
        return countries.stream().allMatch(country -> country.timezones().size()>0);
    }

    public static Country feladat20(List<Country> countries){
        return countries.stream().
                filter(country -> country.name().charAt(0)=='H')//0as indexu karakter==H
                .findFirst()
                .get();
    }


}

