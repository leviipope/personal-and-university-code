/**
 * Provides classes for implementing repositories of objects read from a static
 * JSON resource.
 */
package repository;