import countries.CountryRepository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Application {
    public static void main(String[] args) {
        // kiiratás
        // - consumer (elfogyaszt es nem ad ki semmit)
//        final var numbers = List.of(
//                4, 2, 7, 1
//        );

//        numbers.stream()
//                .peek( // amikor peeket hasznalunk, akkor tolist-et, és hasznalhato hogy hogy nez ki a stream épp, küztem lépés
//                        System.out::println
//                )
//                .filter(
//                        Application::greaterThenThree // csinaltunk egy metotust és itt meghivjuk application osztalyba van a greater then three method
//                )
//                .forEach( // terminális lépésként
//                        System.out::println // number -> System.out.println(number)
//                );
//            //  .toList()

        // 4 4 7 7 2 1 kimenet-> azert mer minden elem vegimegy a streamen (fuggolegesen), tehat vegimegy a 4 es utana a 7 stb

        // rendezes
        // sorted, limit
        // comperator -> x,y -> x>y?

//        numbers.stream()
//                .sorted(
//                        Comparator.naturalOrder()
//                )
//                .forEach(System.out::println);

        // ha vannak null ertetek

//        final var numbers2 = new ArrayList<Integer>();
//
//        numbers2.add(5);
//        numbers2.add(3);
//        numbers2.add(null);
//        numbers2.add(99);
//
//        numbers.stream()
//                .sorted(
//                        Comparator.nullsFirst(
//                                Comparator.reverseOrder()
//                        )
//                )
//                .forEach(System.out::println);

        final var repository = new CountryRepository();
        final var countries = repository.getAll();

//        countries.stream()
//                .sorted(
//                        Comparator.comparing(
//                                country -> country.name()
//                        )
//                )
//                .limit(5) //limitnek fontos a helye
//                .forEach(System.out::println);

//        countries.stream()
//                .sorted(
//                        Comparator.comparing(
//                                country -> country.name(),
//                                Comparator.comparing(
//                                        countryName -> countryName.length()
//                                )
//                        ).thenComparing(
//                                Comparator.naturalOrder()
//                        )
//                )
//                .limit(5)
//                .forEach(System.out::println);

        // kereses
        // anymatch, allmatch, findany, count

        // van e olyan orszag h nincs fovarosa
//        final var res = countries.stream()
//                .anyMatch(
//                        c -> c.capital() == null
//                ); // az anymatch booleant ad vissza
//        System.out.println(res);

        // miyen orszag az aminek nincs fovarasoa
//        final var res = countries.stream()
//                .filter(
//                        c -> c.capital() == null
//                )
//                .findFirst();
//        System.out.println(res);

        // hany orzag minek nicn fovarosa
//        final var res = countries.stream()
//                .filter(
//                        c -> c.capital() == null
//                )
//                .count();
//        System.out.println(res);

//        final var res = countries.stream()
//                .filter(
//                        c -> c.name().length() == 0
//                )
//                .findFirst();
//        System.out.println(res);

        // végtelen stream (főleg ha nins a limit:D)
//        Stream.generate(
//                () -> 5
//        ).limit(10).forEach(System.out::println);



        // streamekbe lista
//
//        final var res = countries.stream()
//                .map(
//                        c -> c.timezones()
//                )
//                .toList();
//        // olyan stream aminek elemei listak
//
//        System.out.println(res);

//        olyan streamet szeretnennk amibe idozonak vannk

//        final var res = countries.stream()
//                .map(
//                        c -> c.timezones()
//                )
//                .flatMap(
//                        l -> l.stream()
//                )
//                .distinct() // ha ez nincs akkor lesznek duplicatek
//                .toList();
//        System.out.println(res);
//        // flatmap: [x,y] [a,d] [x a] => [x, a, x, y, a, d]

        // minden orszagnak az olasz neve
//
//        final var res = countries.stream()
//                .map(
//                        c -> c.translations()
//                )
//                .flatMap(
//                        m -> m.entrySet().stream() //mapeket nem lehet csak ugy streamelni mer van kulcsai es ertekei
//                )
//                .filter(
//                        entry -> entry.getKey().equals("it")
//                )
//                .toList();
//        // forditas, forditas streambe, csak olasz, listbe
//        System.out.println(res);
//

        // collectors
        // tolist, tomap, groupingby

        // eddig mindig kiirtuk vagy listaba gyujtottuk az eredmenyt
        // collect = gyujto, tudunk ani collectot ami vhogy osszegyujti vhogy az melket, megahtarozatod te is de avan sok elore meghatarzott mod
//        final var res = countries.stream()
//                .collect(
//                            Collectors.groupingBy(
//                                    c -> c.region(),
//                                    Collectors.counting()
//                            )
//                        );
//        System.out.println(res);
        // grouping by-nak van 2 parameterezese
        // downstream


        // regionkent melyik lesz a legnepesebb orszag
        final var res = countries.stream()
                .collect(
                        Collectors.groupingBy(
                                c -> c.region(),
                                Collectors.maxBy(
                                        Comparator.comparing(
                                                c -> c.population()
                                        )
                                )
                        )
                );
        System.out.println(res);













    }
//    public static boolean greaterThenThree(int n){
//        return n > 3;
}