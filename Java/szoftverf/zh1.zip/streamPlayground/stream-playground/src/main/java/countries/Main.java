package countries;


import java.util.Comparator;
import java.util.List;
import java.util.LongSummaryStatistics;

public class Main {
    public static void main(String[] args) {
        List<Country> coutries=new CountryRepository().getAll();//beolvassa majd visszaadja a jason filet


        //feladat1(coutries);
        //feladat2(coutries);
        //feladat3(coutries);
        //System.out.println(feladat4(coutries));
        //System.out.println(feladat5(coutries));
        //System.out.println(feladat6(coutries));
        // feladat7(coutries);
        // System.out.println(feladat8(coutries));
        //System.out.println(feladat9(coutries));
        //feladat10(coutries);
        //feladat11(coutries);
        //System.out.println(feladat12(coutries));
        //feladat17(coutries);
        //System.out.println(feladat18(coutries));
        //System.out.println(feladat19(coutries));
        System.out.println(feladat20(coutries));
    }


    public static void feladat1(List<Country> countries){//hogy ne kelljen peldanyositani  a main t
        countries.stream()
                .map(country -> country.name())//map=lekepezes  .map(Country::name).forEach.....ugyanaz
                .forEach(System.out::println);
    }


    public static void feladat2(List<Country> countries) {
        countries.stream()
                .map(Country::capital)
                .sorted(Comparator.nullsFirst(Comparator.naturalOrder()))//ide kell comparator mert maskepp hiba lesz a null miatt, ketto kell mert az elso a nullt kezeli a masodik a tobbit
                .forEach(System.out::println);
    }

    public static void feladat3(List<Country> countries) {
        countries.stream()
                .map(Country::capital)
                .sorted(Comparator.nullsFirst(Comparator.reverseOrder()))
                .forEach(System.out::println);
    }

    public static Long feladat4(List<Country> countries){
        return countries.stream()
                .mapToLong(country->country.population())
                .max()
                .getAsLong();//long formaban add vissza
        //sima map is jo lenne
    }

    public static Double feladat5(List<Country> countries){
        return countries.stream()
                .mapToLong(country->country.population())
                .average()
                .getAsDouble();//mapTolong kell ide mert olyanertekeknek tud atlagot szamolni

    }

    public static LongSummaryStatistics feladat6(List<Country> countries){
        return countries.
                stream()
                .mapToLong(Country::population)
                .summaryStatistics();//keszit egy osszegzo statisztikat
    }

    public static void feladat7(List<Country> countries)//mert konzolra irunk ezert void
    {
        countries.stream()
                .filter(country->country.region()==Region.EUROPE)
                .map(Country::name)
                .forEach(System.out::println);
    }

    public static Long feladat8(List<Country> countries)
    {
        return countries.stream()
                .filter(country->country.region()==Region.EUROPE)
                .count();
    }

    public static Long feladat9(List<Country> countries)
    {
        return countries.stream()
                .filter(country->country.independent())
                .count();
    }

    public static void feladat10(List<Country>countries){
        countries.stream()
                .filter(country -> country.population()<100)
                .forEach(System.out::println);
    }
    public static void feladat11(List<Country>countries){
        countries.stream()
                .filter(country -> country.population()<100)
                .map(Country::name)
                .forEach(System.out::println);
    }

    public static long feladat12(List<Country> countries){
        return countries.stream()
                .filter(country -> country.region()==Region.EUROPE)
                .mapToLong(Country::population)
                .sum();
    }

    public static void feladat17(List<Country> countries){
        countries.stream()
                .map(country -> country.name())
                .limit(5)
                .forEach(System.out::println);
    }

    public static boolean feladat18(List<Country> countries){
        return countries.stream()
                .anyMatch(country -> country.population()==0);
    }

    public static boolean feladat19(List<Country> countries){
        return countries.stream().allMatch(country -> country.timezones().size()>0);
    }

    public static Country feladat20(List<Country> countries){
        return countries.stream().
                filter(country -> country.name().charAt(0)=='H')//0as indexu karakter==H
                .findFirst()
                .get();
    }


}

